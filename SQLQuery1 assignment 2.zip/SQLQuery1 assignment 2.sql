create table Customer
(Customer_id int primary key,
first_name varchar(20),
last_name varchar(20),
email varchar(20),
address varchar(255),
city varchar(30),
state varchar(30),
zip varchar(20)
)

select * from Customer

insert into Customer
(Customer_id,first_name,last_name,email,address,city,state,zip)
values
(1,'Garry','williams','garry@gmail.com','America','San Jose','California','cal78999')

insert into Customer
(Customer_id,first_name,last_name,email,address,city,state,zip)
values
(2,'George','Stevension','George1223@gmail.com','UK','San Jose','Barminghum','UK78999')

insert into Customer
(Customer_id,first_name,last_name,email,address,city,state,zip)
values
(3,'Afridi','Rahaman','rahaman@gmail.com','India','Mumbai','Maharastra','MH78999')

insert into Customer
(Customer_id,first_name,last_name,email,address,city,state,zip)
values
(4,'Rahul','Paul','rahul@gmail.com','India','Kolkata','WestBengal','Kol756099')

insert into Customer
(Customer_id,first_name,last_name,email,address,city,state,zip)
values
(5,'Samiya','Islam','samiya@gmail.com','SriLanka','Colombo','Thiruvananthapuram','SL78999')

select * from Customer

select first_name, last_name from Customer;

select * from Customer















